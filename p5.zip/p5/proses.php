<?php
if($_SERVER['REQUEST_METHOD'] == "POST") {
    echo "<br> NIS : ".$_POST['nis'];
    echo "<br> Nama : ".$_POST['nama'];
    echo "<br> Jenis Kelamin : ".$_POST['jk'];
    echo "<br> Kota : ".$_POST['kota'];
    echo "<br> Tanggal Lahir : ".$_POST['tgl-lahir'];

    $nis    = $_POST['nis'];
    $nama    = $_POST['nama'];
    $jk    = $_POST['jk'];
    $tanggalLahir    = $_POST['tgl-lahir'];
    $kota    = $_POST['kota'];
    $foto   = $_FILES['foto'];

    // echo $nis, "<br>";
    // echo $nama, "<br>";
    // echo $jk, "<br>";
    // echo $tanggalLahir, "<br>";
    // echo $kota, "<br>";
    // var_dump($foto);

    // $temp = explode (".", $_FILES["foto"]["name"]);
    // $newfilename = $nis . "." . end($temp);
    // move_uploaded_file($_FILES["foto"]["tmp_name"], "uploads/". $newfilename);

} else {
    echo "Silahkan isi nis terlebih dahulu";
}

echo"<table>
<tr>
        <th rowspan=2>NIS</th>
        <th rowspan=2> : </th>";
        echo "<th rowspan=2>".$_POST['nis']."</th>";

        echo "<tr><td colspan='5'>Nama</td><td> : </td><td>".$_POST['nama']."</td></tr>";

// </tr>";
// echo"<tr>
//         <td> : </td>
//         <td>AM</td>
//         <td>K</td>
//         <td>M</td>
// </tr>";
// $total_k = 0; $total_m = 0; $total_d = 0;
// $adaD = false; $adaE = false;

// foreach($Latihan as $data){
//     if ($data['Hm'] == 'D') {
//         $adaD = true;
//         $total_d += $data['K'];
//     }

//     if ($data['Hm'] == 'E') {
//         $adaE = true;
//     }

//     $total_k += $data['k'];
//     $total_m += getM(getAmByHM($data['Hm']),$data['k']);
//     echo "<tr>
//         <td>".$data['no']."</td>
//         <td>".$data['matakuliah']."</td>
//         <td>".$data['Kode-Matakuliah']."</td>
//         <td>".$data['Hm']."</td>
//         <td>".getAmByHM($data['Hm'])."</td>
//         <td>".$data['k']."</td>
//         <td>".getM(getAmByHM($data['Hm']),$data['k'])."</td>
        
//         </tr>";
// }

// $ujian = "A";

// echo "<tr><td colspan='5'>JUMLAH</td><td>".$total_k."</td><td>".$total_m."</td></tr>";
// $ipk = getIPK($total_m, $total_k);
// echo "<tr><td colspan='5'>IPK</td><td colspan='2'>".$ipk."</td></tr>";
// echo "<tr><td colspan='7'>Predikat : ".getPredikat($ipk)."</td></tr>";
// echo "<tr><td colspan='7'>Yudisium : ".getYudisium($ipk, $total_d, $adaE, $ujian)."</td></tr>";
// echo"</table>";
?>